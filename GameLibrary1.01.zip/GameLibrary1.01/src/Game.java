import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.Timer;

/**
 * GameLibrary全体のクラスの管理を行うクラス.
 * <p>
 * 主な仕事は、それぞれのクラスの関数を適切なタイミングで呼び出すこと
 * </p>
 */
public class Game extends JFrame implements ActionListener {
	private GameLibrary	lib;
	private Input				input;
	private Draw				draw;
	private Timer				timer;
	// 描画域の横幅、縦幅、及びゲーム開始からの経過フレーム数
	private int					wid, hei, frame;
	// コンストラクタ及びuserInitが実行済みか否か
	private boolean			endCons	= false, endInit = false;

	/**
	 * ゲーム本体のクラスのコンストラクタで呼び出すこと.
	 * 
	 * @param title ウィンドウに表示するタイトル
	 * @param libInput ゲーム本体のクラスで宣言したInputクラス
	 * @param libDraw ゲーム本体のクラスで宣言したDrawクラス
	 * @param library ゲーム本体のクラス、"this"と引き渡せば良い
	 * @param width ウィンドウの「描画域」の横幅
	 * @param height ウィンドウの「描画域」の縦幅
	 * @param fps 実行速度の指定、単位は1秒間に実行されるフレーム数（Frame Per Second）
	 */
	public Game (String title, Input libInput, Draw libDraw, GameLibrary library,
			int width, int height, int fps) {
		input = libInput;
		draw = libDraw;
		lib = library;
		wid = width;
		hei = height;
		frame = 0;

		Container conpane = getContentPane();

		timer = new javax.swing.Timer(1000 / fps, this);
		timer.start();

		setBackground(Color.BLACK);
		setTitle(title);
		conpane.setPreferredSize(new Dimension(wid, hei));
		pack();

		add(draw);
		conpane.add(draw);
		addKeyListener(input);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

		// ウィンドウが閉じるときの処理
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				lib.cleanup();
				System.exit(0);
			}
		});
		endCons = true;
	}

	/**
	 * ゲーム本体のクラスのコンストラクタで呼び出すこと.
	 * <p>
	 * 特に指定が無い場合、 実行速度は60FPSとなる
	 * </p>
	 * 
	 * @param title ウィンドウに表示するタイトル
	 * @param libInput ゲーム本体のクラスで宣言したInputクラス
	 * @param libDraw ゲーム本体のクラスで宣言したDrawクラス
	 * @param library ゲーム本体のクラス、"this"と引き渡せば良い
	 * @param width ウィンドウの「描画域」の横幅
	 * @param height ウィンドウの「描画域」の縦幅
	 */
	public Game (String title, Input libInput, Draw libDraw, GameLibrary library,
			int width, int height) {
		this(title, libInput, libDraw, library, width, height, 60);
	}

	/**
	 * ゲーム本体のクラスのコンストラクタで呼び出すこと.
	 * <p>
	 * 特に指定が無い場合、 ウィンドウの「描画域」のサイズはデフォルトで640*480、 実行速度は60FPSとなる
	 * </p>
	 * 
	 * @param title ウィンドウに表示するタイトル
	 * @param libInput ゲーム本体のクラスで宣言したInputクラス
	 * @param libDraw ゲーム本体のクラスで宣言したDrawクラス
	 * @param library ゲーム本体のクラス、"this"と引き渡せば良い
	 */
	public Game (String title, Input libInput, Draw libDraw, GameLibrary library) {
		this(title, libInput, libDraw, library, 640, 480, 60);
	}

	/**
	 * ウィンドウの「描画域」の横幅を返す関数.
	 * 
	 * @return 描画域の横幅
	 */
	public int getScreenWidth() {
		return wid;
	}

	/**
	 * ウィンドウの「描画域」の縦幅を返す関数.
	 * 
	 * @return 描画域の縦幅
	 */
	public int getScreenHeight() {
		return hei;
	}

	/**
	 * ゲーム開始からの経過フレーム数を返す関数.
	 * 
	 * @return 経過フレーム数
	 */
	public int getFrame() {
		return frame;
	}

	/**
	 * 現在の実現FPSを返す関数.
	 * <p>
	 * 試験中
	 * </p>
	 * 
	 * @return 現在のFPS
	 */
	public double getFPS() {
		return 1000 / timer.getDelay();
	}

	@ Override
	/**
	 * ActionListenerよりオーバーロードした関数.
	 * <p>
	 * 外部から決して触らないこと！
	 * </p>
	 */
	public void actionPerformed(ActionEvent arg0) {
		if (!endCons) return;
		else if (!endInit) {
			lib.userInit();
			endInit = true;
			return;
		}

		// 入力状況の更新
		input.update();
		// mainloopの実行
		lib.mainloop();
		// 再描画
		repaint();

		++frame;
	}
}

// GameLibraryの機能を提供するクラスが実装する必要があるインターフェース
// 以下の3つの関数をGameクラスが適切なタイミングで呼び出す（はず！）
interface GameLibrary {
	void userInit();

	void mainloop();

	void cleanup();
}
