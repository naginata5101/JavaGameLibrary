import java.awt.Color;
import java.awt.Font;

public class Sample implements GameLibrary {
	public static void main(String[] args) {
		new Sample();
	}

	private Draw	draw;
	private Input	input;
	private Game	game;
	
	private int x, y;
	private final int w = 100, h = 50;

	public Sample () {
		input = new Input();
		draw = new Draw();
		game = new Game("Game Title", input, draw, this);
	}

	@ Override
	public void userInit() {
		x = 0;
		y = game.getScreenHeight();
	}

	@ Override
	public void mainloop() {
		draw.drawFillRect(Color.RED, x, y - h, w, h);
		++x;
		--y;
		
		if (input.getKeyNum(KeyType.K_ESC) > 0) System.exit(0);
	}

	@ Override
	public void cleanup() {}
}
